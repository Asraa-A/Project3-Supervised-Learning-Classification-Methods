install.packages("class")
install.packages("psych")
install.packages("corrplot")
install.packages("skimr")
install.packages("rpart")
install.packages("rpart.plot")
install.packages("randomForest")
install.packages("ggplot2")
install.packages("forcats")
install.packages("caret")
install.packages("dplyr")
install.packages("tidyr")
install.packages("RColorBrewer")
install.packages("rattle")
install.packages("ISLR")
install.packages("ROCR")
install.packages("e1071")
install.packages("GGally")
install.packages("pROC")
install.packages("caretEnsemble")
install.packages("libcoin")
install.packages("knitr")
install.packages("e1071")
install.packages("C50")
install.packages("gridExtra")
library(class)
library(psych)
library(corrplot)
library(skimr)
library(rpart)
library(rpart.plot)
library(randomForest)
library(ggplot2)
library(forcats)
library(caret)
library(dplyr)
library(tidyr)
library(RColorBrewer)
library(rattle)
library(ISLR)
library(ROCR)
library(e1071)
library(GGally)
library(pROC)
library(caretEnsemble)
library(libcoin)
library(knitr)
library(e1071)
library(C50)
library(gridExtra)

nba_prediction <- read.csv("prediction_data_optional.csv",header=TRUE)

#k-Fold cross validation.
set.seed(234)
control <-
  trainControl(
    method = "repeatedcv",
    repeats = 3,
    number = 10,
    allowParallel = TRUE
  )
rf_cv <-
  train(
    Target ~ .,
    data = train_set[, -1],
    method = "rf",
    trControl = control,
    tuneLength = 9,
    importance = TRUE
  )

pred_nba_class<- predict(rf_cv, nba_prediction )
pred_nba_prob <- predict(rf_cv, nba_prediction  , "prob")