install.packages("class")
install.packages("psych")
install.packages("corrplot")
install.packages("skimr")
install.packages("rpart")
install.packages("rpart.plot")
install.packages("randomForest")
install.packages("ggplot2")
install.packages("forcats")
install.packages("caret")
install.packages("dplyr")
install.packages("tidyr")
install.packages("RColorBrewer")
install.packages("rattle")
install.packages("ISLR")
install.packages("ROCR")
install.packages("e1071")
install.packages("GGally")
install.packages("pROC")
install.packages("caretEnsemble")
install.packages("libcoin")
install.packages("knitr")
install.packages("e1071")
install.packages("C50")
install.packages("gridExtra")
library(class)
library(psych)
library(corrplot)
library(skimr)
library(rpart)
library(rpart.plot)
library(randomForest)
library(ggplot2)
library(forcats)
library(caret)
library(dplyr)
library(tidyr)
library(RColorBrewer)
library(rattle)
library(ISLR)
library(ROCR)
library(e1071)
library(GGally)
library(pROC)
library(caretEnsemble)
library(libcoin)
library(knitr)
library(e1071)
library(C50)
library(gridExtra)


######################################################################################################################
nba_df <- read.csv("nba_rookies_data.csv", header = TRUE)
str(nba_df, vec.len = 2)

##Explanatory of data plot the data to see any unusual features

str(nba_df)
#summary of the data
summary(nba_df)
kable(skim(train_set[,-1]))
#pairs plot of the data 
ggpairs(
  train_set[, -1],
  aes(color = Target, fill = Target) ,
  lower = list(continuous = "cor"),
  upper = list(continuous = wrap("points", alpha = 0.5))
)

##feature plot using Caret
featurePlot(train_set[, -1], train_set$Target, plot = "pairs")
#notice most of the variables are highly correlated
corrplot(cor(train_set[, -c(1, 12)]), method = "number", type = "upper")

# the first line is the only one that you should change (according to the last
# two digits of your student ID)
set.seed(94)
alpha <- 0.5 # percentage of training set
beta <- 0.25 # percentage of validation set
inTrain <- sample(1:nrow(nba_df), alpha * nrow(nba_df))
inValid <- sample(c(1:nrow(nba_df))[-inTrain], beta * nrow(nba_df))
train_set_initial <- nba_df[inTrain, ]
valid_set_initial <- nba_df[inValid, ]
test_set_initial <- nba_df[-c(inTrain, inValid), ]

dim(train_set_initial)
dim(valid_set_initial)
dim(valid_set_initial)


set.seed(94) # Change the value to the last two digits of your student ID
random_sample <- sample(6:21, 7) #Choose 7 variables randomly
train_set <- train_set_initial[, c(1, 3:5, random_sample, 23)]
valid_set <- valid_set_initial[, c(1, 3:5, random_sample, 23)]
test_set <- test_set_initial[, c(1, 3:5, random_sample, 23)]
#######################################################################################################
# Target as a factor with two levels yes refer to 1 and no refer to 0

train_set$Target <- factor(train_set$Target,levels=c(1,0),labels = c("yes","no"))
valid_set$Target <- factor(valid_set$Target,levels=c(1,0),labels = c("yes","no"))
test_set$Target <- factor(test_set$Target,levels=c(1,0),labels = c("yes","no"))
#provide data summary

train_tree<- rbind(train_set,valid_set)

################################################################################################################################
#Fully grown tree
#################

set.seed(234)
#using rpart
full_tree <- rpart(Target ~ ., data = train_set[, -1], method = "class")
#plot the Tree

fancyRpartPlot(full_tree)

## Predicting the valid set results,calculate the confusion matrix and area under the curve
#predicting the class of the valid set

pred_f_class <- predict(full_tree, newdata = valid_set, type = "class")

#predicting the probability

pred_f_prob <- predict(full_tree, newdata = valid_set, type = "prob")

#calculate the correct classification rate

conf_mat_f <- table(pred_f_class, valid_set$Target)
class_rate_f <- sum(diag(conf_mat_f)) / sum(conf_mat_f)
paste('Accuracy', round(class_rate_f, 4))

#confusion matrix

confusionMatrix(data = pred_f_class, reference = valid_set$Target)

##Receiver operating characteristic (ROC)and area under the curve (AUC)

full_tree_ROC <- roc(valid_set$Target, pred_f_prob[, "1"])
plot(full_tree_ROC, col = "black")
auc(full_tree_ROC)

############################################
############################################

## Pruneing the tress manually
##find the optimal cp and prune the tree

pruntree <-
  prune(full_tree, cp = full_tree$cptable[which.min(full_tree$cptable[, "xerror"]), "CP"])

#predict the valid set class

pred_prun_class <-
  predict(pruntree, newdata = valid_set, type = "class")

#predict the valid set probability

pred_prun_prob <-
  predict(pruntree, newdata = valid_set, type = "prob")

#calculate the correct classification rate

conf_mat_prun <- table(pred_prun_class, valid_set$Target)
class_rate_prunt <-  sum(diag(conf_mat_prun)) / sum(conf_mat_prun)
paste('Accuracy', round(class_rate_prunt, 4))
#0.6816479
#plot the prune tree

fancyRpartPlot(pruntree)
#confusion matrix
confusionMatrix(data = pred_prun_class, reference = valid_set$Target)

############################################
############################################

## Using Repeated k-fold cross validation for optimal cp and tree pruning
set.seed(234)
control <-
  trainControl(method = "repeatedcv",
               repeats = 3,
               number = 10)

cv_tree <-
  train(
    Target ~ .,
    data = train_set[, -1],
    method = "rpart",
    trControl = control,
    tuneLength = 10
  )

cv_tree
#plot the cross validated tree
fancyRpartPlot(cv_tree$finalModel  ,main="Pruned Tree", sub= "10-Fold Cross Validation")
plot(cv_tree)


#predict the valid set class
pred_cv_class <- predict(cv_tree, valid_set)
#predict the valid set probability
pred_cv_prob <- predict(cv_tree, valid_set, "prob")
#calculate the correct classification error
conf_mat_cv <- table(pred_cv_class, valid_set$Target)
class_rate_cv <- sum(diag(conf_mat_cv)) / sum(conf_mat_cv)
paste('Accuracy', round(class_rate_cv, 4))


#calculate the confusion matrix
confusionMatrix(pred_cv_class, valid_set$Target)

##Receiver operating characteristic (ROC)and area under the curve (AUC)
cv_tree_ROC <- roc(valid_set$Target, pred_cv_prob[, "yes"])
plot(cv_tree_ROC, col = "green")
auc(cv_tree_ROC)

#####################################################################################################################
##bagging
#######################





##mtry=number of predictors

#use bagging in randomforest ans specify mtry as the number of predictor
set.seed(234)
bag_tree <-
  randomForest(Target ~ . ,
               data = train_set[, -1],
               mtry = 10,
               ntree = 200)

bag_tree
#plot no of trees with error
plot(bag_tree)

#predict the valid set
pred_bag_class <- predict(bag_tree, valid_set , "class")
pred_bag_prob <- predict(bag_tree, valid_set , "prob")
#calculate classification rate
conf_mat_bag <- table(pred_bag_class, valid_set$Target)
class_rate_bag <-  sum(diag(conf_mat_bag)) / sum(conf_mat_bag)
paste('Accuracy', round(class_rate_bag, 4))
#0.7425
#Calculate the confusion matrix
confusionMatrix(data = pred_bag_class, reference = valid_set$Target)
#plot ROC and calculate AUC
bag_tree_ROC <- roc(valid_set$Target, pred_bag_prob[, "yes"])
plot(bag_tree_ROC, col = "red")
auc(bag_tree_ROC)


#K-Fold cross validation bagging

set.seed(234)
control <-
  trainControl(method = "repeatedcv",
               repeats = 3,
               number = 10)

bag_cv <-
  train(
    Target ~ .,
    data = train_set[, -1],
    method = "treebag",
    trControl = control,
    importance = TRUE,
    tuneLength = 10
  )


#print the output
bag_cv
#plot variable importance
plot(varImp(bag_cv), main = "Bagging Variable importance")
#predict valid_set and calculate accuracy
pred_bagcv_class <- predict(bag_cv, valid_set)
pred_bagcv_prob <- predict(bag_cv, valid_set , "prob")
conf_mat_bagcv <- table(pred_bagcv_class, valid_set$Target)
class_rate_bagcv <-  sum(diag(conf_mat_bagcv)) / sum(conf_mat_bagcv)
paste('Accuracy', round(class_rate_bagcv, 4))

#calculate the confusion matrix
confusionMatrix(data = pred_bagcv_class, reference = valid_set$Target)

#plot ROC and calculate AUC
bag_cv_ROC <- roc(valid_set$Target, pred_bagcv_prob[, "yes"])
plot(bag_cv_ROC, col = "red")
auc(bag_cv_ROC)

#######################################################################################################################
#Random Forest
####################



set.seed(234)
rf_tree <- randomForest(Target ~ . , data = train_set[, -1])
plot(rf_tree)
#prediction using valid data
pred_rf_class <- predict(rf_tree, valid_set , "class")
pred_rf_prob <- predict(rf_tree, valid_set , "prob")
#calculate the classification rate
conf_mat_rf <- table(pred_rf_class, valid_set$Target)
class_rate_rf <-  sum(diag(conf_mat_rf)) / sum(conf_mat_rf)
paste('Accuracy', round(class_rate_rf, 4))
#0.7425
confusionMatrix(data = pred_rf_class, reference = valid_set$Target)
#ROC
rf_tree_ROC <- roc(valid_set$Target, pred_rf_prob[, "yes"])
plot(rf_tree_ROC, col = "orange")
auc(rf_tree_ROC)

#k-Fold cross validation.
set.seed(234)
control <-
  trainControl(
    method = "repeatedcv",
    repeats = 3,
    number = 10,
    allowParallel = TRUE
  )
rf_cv <-
  train(
    Target ~ .,
    data = train_set[, -1],
    method = "rf",
    trControl = control,
    tuneLength = 9,
    importance = TRUE
  )

rf_cv
plot(rf_cv)
plot(rf_cv$finalModel)
plot(varImp(rf_cv),main="Random Forests Variable Importance",xlab="Average Decrease in Gini Index")
#predict the test data
pred_rfcv_class <- predict(rf_cv, valid_set)
pred_rfcv_prob <- predict(rf_cv, valid_set , "prob")
conf_mat_rfcv <- table(pred_rfcv_class, valid_set$Target)
class_rate_rfcv <-  sum(diag(conf_mat_rfcv)) / sum(conf_mat_rfcv)
paste('Accuracy', round(class_rate_rfcv, 4))

#confsion matrix
confusionMatrix(data = pred_rfcv_class, reference = valid_set$Target)

#plot ROC
rfcv_tree_ROC <- roc(valid_set$Target, pred_rfcv_prob[, "yes"])
plot(rfcv_tree_ROC, col = "brown")
#Calculate AUC
auc(rfcv_tree_ROC)


#####################################################################################################################################
#boosting
#########################



#comparison between gbm boost and C50,C50 gives higher accuracy
set.seed(234)
caretGrid <-
  expand.grid(
    interaction.depth = 6,
    n.trees = 3000,
    shrinkage = 0.01,
    n.minobsinnode = 10
  )

trainControl <-
  trainControl(
    method = "repeatedcv",
    repeats = 3,
    number = 10,
    classProbs = TRUE,
    summaryFunction = twoClassSummary
  )

gbm_boost <-
  train(
    Target ~ .,
    data = train_set[, -1],
    method = "gbm",
    trControl = trainControl,
    verbose = FALSE,
    distribution = "bernoulli",
    bag.fraction = 0.4
  )

#predict using the valid data
pred_gbmcv_class <- predict(gbm_boost, valid_set)
pred_gbmcv_prob <- predict(gbm_boost, valid_set[, -1] , "prob")
#calculate the correct classification rate
conf_mat_gbmcv <- table(pred_gbmcv_class, valid_set$Target)
class_rate_gbmcv <-  sum(diag(conf_mat_gbmcv)) / sum(conf_mat_gbmcv)
paste('Accuracy', round(class_rate_gbmcv, 4))

#confusion matrix 
confusionMatrix(data = pred_gbmcv_class, reference = valid_set$Target)

#plot ROC
gbmcv_tree_ROC <- roc(valid_set$Target, pred_gbmcv_prob[, "yes"])
plot(gbmcv_tree_ROC , col = "pink")
#Calculate AUC
auc(gbmcv_tree_ROC)

####################################################################################################################
##Boosting with C50 package adaboost
######################################

set.seed(234)
control <-
  trainControl(
    method = "repeatedcv",
    number = 10,
    repeats = 3,
    classProbs = TRUE,
    summaryFunction = twoClassSummary
  )

boostc50 <-
  train(
    Target ~ .,
    data = train_set[,-1],
    method = "C5.0",
    metric = "ROC",
    trControl = control
  )

#plot the variable importance
plot(varImp(boostc50), main = "Boosting Variable Importance", xlab = "Average Decrease in Gini Index")

#classification error and confusion matrix
pred_boost_class <- predict(boostc50 , valid_set)
pred_boost_prob <- predict(boostc50 , valid_set , "prob")
#calculate the classification rate
conf_mat_boost <- table(pred_boost_class, valid_set$Target)
class_rate_boost <-  sum(diag(conf_mat_boost)) / sum(conf_mat_boost)
paste('Accuracy', round(class_rate_boost, 4))


#confsion matrix
confusionMatrix(data = pred_boost_class, reference = valid_set$Target)

#plot ROC
boost_tree_ROC <- roc(valid_set$Target, pred_boost_prob[, "yes"])
plot(boost_tree_ROC, col = "pink")
#Calculate AUC
auc(boost_tree_ROC)



#########################################################################################################################
#Knn
################


set.seed(234)
#repeated k-fold cross validation
control <-
  trainControl(method = "repeatedcv",
               number = 10,
               repeats = 3)

#fit the model with CARET,data preprocessing is center and scale of variables.
knn_fit <-
  train(
    Target ~ .,
    data = train_set[,-1],
    method = "knn",
    trControl = control,
    preProcess = c("center", "scale"),
    tuneLength = 10
  )
#print output
knn_fit

#plot of k with classification rate
plot(knn_fit , main = "Correct Classification rate vs K")

#predict using the valid set
pred_knn_class <- predict(knn_fit, valid_set)
pred_knn_prob <- predict(knn_fit, valid_set , "prob")

#calculate the correct calssification rate
conf_mat_knn <- table(pred_knn_class, valid_set$Target)
class_rate_knn <-  sum(diag(conf_mat_knn)) / sum(conf_mat_knn)
paste('Accuracy', round(class_rate_knn, 4))

#confusion matrix
confusionMatrix(data = pred_knn_class, reference = valid_set$Target)

#plot ROC
knn_ROC <- roc(valid_set$Target, pred_knn_prob[, "yes"])
plot(knn_ROC, col = "darkgrey")
#Calculate AUC
auc(knn_ROC)
#################################################################################################################
##SVM linear
####################


# Fitting Linear SVM to the Training set
#centering and scaling data
scaleobj <- preProcess(train_set , method = c("center", "scale"))
train_set_scale <- predict(scaleobj , train_set)
valid_set_scale <- predict(scaleobj , valid_set)
test_set_scale <- predict(scaleobj , test_set)


#fit a linear svm
set.seed(234)
SVML <-
  svm(
    Target ~ .,
    data = train_set_scale[, -1],
    type = 'C-classification',
    kernel = 'linear' ,
    probability = T
  )

#predict using the valid set
pred_SVML_class <- predict(SVML, valid_set_scale)
pred_SVML_prob <- predict(SVML, valid_set_scale , probability = T)

#calculate the correct classification rate
conf_mat_SVML <- table(pred_SVML_class, valid_set_scale$Target)
class_rate_SVML <-  sum(diag(conf_mat_SVML)) / sum(conf_mat_SVML)
paste('Accuracy', round(class_rate_SVML, 4))

#confusion matrix
confusionMatrix(data = pred_SVML_class, reference = valid_set_scale$Target)

#plot Roc and calculate AUC
SVML_prop <- attr(pred_SVML_prob, "probabilities")
L_ROC <- roc(valid_set_scale$Target, SVML_prop[1:267])
plot(L_ROC, col = "darkgrey")
#Calculate AUC
auc(L_ROC)


##tuning the parameter of linear svm
set.seed(234)
#parameter tuning linear svm
L_tune <-
  tune(
    svm,
    Target ~ . ,
    data = train_set_scale[, -1],
    kernel = "linear",
    type = "C-classification",
    probability = T,
    ranges = list(cost = c(10 ^ (-2:2)))
  )
summary(L_tune)$best.parameters

#predict using the valid set
pred_Ltune_class <- predict(L_tune$best.model, valid_set_scale)
pred_Ltune_prob <-
  predict(L_tune$best.model, valid_set_scale , probability = T)

#calculate the correct classification rate
#conf_mat_Ltune<- table(pred_Ltune_class,valid_set$Target)
class_rate_Ltune <-  mean(pred_Ltune_class == valid_set_scale$Target)
paste('Accuracy', round(class_rate_Ltune, 4))

#confusion matrix
confusionMatrix(data = pred_Ltune_class, reference = valid_set_scale$Target)

#plot ROC
SVMLt_prop <- attr(pred_Ltune_prob, "probabilities")
Lt_ROC <- roc(valid_set_scale$Target, SVMLt_prop[1:267])
plot(Lt_ROC, col = "darkgrey")
#Calculate AUC
auc(Lt_ROC)


#####################################################################################################################
#svm radial
###############
set.seed(234)
#fit the model
SVMR <-
  svm(
    Target ~ .,
    data = train_set_scale[, -1],
    type = 'C-classification',
    kernel = 'radial' ,
    probability = T
  )

#predict the valid set
pred_SVMR_class <- predict(SVMR, valid_set_scale)
pred_SVMR_prob <- predict(SVMR, valid_set_scale , probability = T)
conf_mat_SVMR <- table(pred_SVMR_class, valid_set_scale$Target)

#calculate correct calssification rate
class_rate_SVMR <-  sum(diag(conf_mat_SVMR)) / sum(conf_mat_SVMR)
paste('Accuracy', round(class_rate_SVMR, 4))

#confusion matrix
confusionMatrix(data = pred_SVMR_class, reference = valid_set_scale$Target)

#plot ROC
SVMR_prop <- attr(pred_SVMR_prob, "probabilities")
R_ROC <- roc(valid_set_scale$Target, SVMR_prop[1:267])
plot(R_ROC, col = "darkgrey")
#Calculate AUC
auc(R_ROC)


#svm Radial parameter tuning
set.seed(234)
#parameter tuning radial svm
R_tune <-
  tune(
    svm,
    Target ~ . ,
    data = train_set_scale[, -1],
    kernel = "radial",
    type = "C-classification",
    probability = T,
    ranges = list(cost = 2 ^ (-2:2), gamma = 2 ^ (-6:-2))
  )
summary(R_tune)$best.parameters

#predict the valid set
pred_Rtune_class <- predict(R_tune$best.model, valid_set_scale)
pred_Rtune_prob <-
  predict(R_tune$best.model, valid_set_scale , probability = T)
#conf_mat_Ltune<- table(pred_Ltune_class,valid_set$Target)

#calculate the correction classification rate
class_rate_Rtune <-  mean(pred_Rtune_class == valid_set_scale$Target)
paste('Accuracy', round(class_rate_Rtune, 4))

#calculate the confusion matrix
confusionMatrix(data = pred_Rtune_class, reference = valid_set_scale$Target)
#0.694
SVMRt_prop <- attr(pred_Rtune_prob, "probabilities")

#plot ROC
Rt_ROC <- roc(valid_set_scale$Target, SVMRt_prop[1:267])
plot(Rt_ROC, col = "darkgrey")
#Calculate AUC
auc(Rt_ROC)

#################################################################################################################
#svm polynomial
####################



set.seed(234)
#fit the model
SVMP <-
  svm(
    Target ~ .,
    data = train_set_scale[, -1],
    type = 'C-classification',
    kernel = 'polynomial',
    probability = T
  )


#predict the valis set
pred_SVMP_class <- predict(SVMP, valid_set_scale)
pred_SVMP_prob <- predict(SVMP, valid_set_scale , probability = T)

#calculate the correct calssification rate
conf_mat_SVMP <- table(pred_SVMP_class, valid_set_scale$Target)
class_rate_SVMP <-  sum(diag(conf_mat_SVMP)) / sum(conf_mat_SVMP)
paste('Accuracy', round(class_rate_SVMP, 4))

#confusion matrix
confusionMatrix(data = pred_SVMP_class, reference = valid_set_scale$Target)


#plot the RoC
SVMP_prop <- attr(pred_SVMP_prob, "probabilities")
P_ROC <- roc(valid_set_scale$Target, SVMP_prop[1:267])
plot(P_ROC, col = "darkgrey")
#Calculate AUC
auc(P_ROC)


#parameter tuning polynomial svm
set.seed(234)

#fit the model
P_tune <-
  tune(
    svm,
    Target ~ . ,
    data = train_set_scale[, -1],
    kernel = "polynomial",
    type = "C-classification",
    probability = T,
    degree = 2,
    ranges = list(cost = 2 ^ (-2:2), gamma = 2 ^ (-6:-2))
  )
summary(P_tune)$best.parameters

#predict the valid set
pred_Ptune_class <- predict(P_tune$best.model, valid_set_scale)
pred_Ptune_prob <-
  predict(P_tune$best.model, valid_set_scale , probability = T)
#conf_mat_Ltune<- table(pred_Ltune_class,valid_set$Target)

#calculate the correct classification rate
class_rate_Ptune <-  mean(pred_Ptune_class == valid_set_scale$Target)
paste('Accuracy', round(class_rate_Ptune, 4))

#confusion matrix
confusionMatrix(data = pred_Ptune_class, reference = valid_set_scale$Target)


#plot the ROC
SVMPt_prop <- attr(pred_Ptune_prob, "probabilities")
Pt_ROC <- roc(valid_set_scale$Target, SVMPt_prop[1:267])
plot(Pt_ROC, col = "darkgrey")
#Calculate AUC
auc(Pt_ROC)

##########################################################################################################################################
##Ensemble and stacking
library("caret")
library("pROC")
library("caTools")
library("caret")
library("pROC")
library("caTools")
set.seed(324)

my_control <- trainControl(
  method="boot",
  number=25,
  savePredictions="final",
  classProbs=TRUE,
  index=createResample(train_set$Target, 25),
  summaryFunction=twoClassSummary
)

model_list <- caretList(
  Target ~. , data=train_set[,-1],
  trControl=my_control,
  methodList=c("gbm","svmRadial","rf")
)


p <- as.data.frame(predict(model_list, newdata=test_set))
print(p)

modelCor(resamples(model_list))

greedy_ensemble <- caretEnsemble(
  model_list, 
  metric="Accuracy",
  trControl=trainControl(
    method="repeatedcv",
    number=10,
    summaryFunction=twoClassSummary,
    classProbs=TRUE
  ))
summary(greedy_ensemble)


model_preds <- lapply(model_list, predict, newdata=test_set, type="prob")
model_preds <- lapply(model_preds, function(x) x[,"yes"])
model_preds <- data.frame(model_preds)
ens_preds <- predict(greedy_ensemble, newdata=test_set, type="prob")
model_preds$ensemble <- ens_preds
caTools::colAUC(model_preds, test_set$Target)

m_ensemble <- caretStack(
  model_list,
  method="svmRadial",
  metric="Accuracy",
  trControl=trainControl(
    method="cv",
    number=10,
    savePredictions="final",
    classProbs=TRUE,
    summaryFunction=twoClassSummary
  )
)


model_preds2 <- model_preds
model_preds2$ensemble <- predict(glm_ensemble, newdata=test_set, type="prob")
CF <- coef(glm_ensemble$ens_model$finalModel)[-1]
colAUC(model_preds2, test_set$Target)




