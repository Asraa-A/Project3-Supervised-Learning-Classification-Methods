
## Simple Tree
pred_cv_class <- predict(cv_tree,test_set)
pred_cv_prob <- predict(cv_tree,test_set,"prob")
conf_mat_cv <- table(pred_cv_class,test_set$Target)
class_rate_cv <- sum(diag(conf_mat_cv))/sum(conf_mat_cv)
#test set  Accuracy
paste('Accuracy',round(class_rate_cv,4))
#0.686
confusionMatrix(pred_cv_class,test_set$Target)
##ROC
cv_tree_ROC <- roc(test_set$Target,pred_cv_prob[,"yes"])
plot( cv_tree_ROC,col="green")
auc(cv_tree_ROC)



##Bag Tree

pred_bagcv_class<- predict(bag_cv,test_set )
pred_bagcv_prob<- predict(bag_cv,test_set ,"prob")
conf_mat_bagcv<- table(pred_bagcv_class,test_set$Target)
class_rate_bagcv<-  sum(diag(conf_mat_bagcv))/sum(conf_mat_bagcv)
paste('Accuracy',round(class_rate_bagcv,4))
#0.7052
confusionMatrix(data = pred_bagcv_class,reference = test_set$Target)
#plot ROC and calculate AUC

#plot ROC and calculate AUC
bag_cv_ROC <- roc(test_set$Target,pred_bagcv_prob[,"yes"])
plot( bag_cv_ROC,col="red")
auc(bag_cv_ROC)


##Random Forests

pred_rfcv_class<- predict(rf_cv,test_set)
pred_rfcv_prob<- predict(rf_cv,test_set ,"prob")
conf_mat_rfcv<- table(pred_rfcv_class,test_set$Target)
class_rate_rfcv<-  sum(diag(conf_mat_rfcv))/sum(conf_mat_rfcv)
paste('Accuracy',round(class_rate_rfcv,4))
#0.7313
#confsion matrix
confusionMatrix(data = pred_rfcv_class,reference = test_set$Target)
#plot ROC
rfcv_tree_ROC <- roc(test_set$Target,pred_rfcv_prob[,"yes"])
plot( rfcv_tree_ROC,col="brown")
#Calculate AUC
auc(rfcv_tree_ROC)


##c50
#classification error and confusion matrix
pred_boost_class <- predict(boostc50 , test_set)
pred_boost_prob <- predict(boostc50 , test_set , "prob")
conf_mat_boost <- table(pred_boost_class, test_set$Target)
class_rate_boost <-  sum(diag(conf_mat_boost)) / sum(conf_mat_boost)
paste('Accuracy', round(class_rate_boost, 4))
#0.7425

#confsion matrix
confusionMatrix(data = pred_boost_class, reference = test_set$Target)
#plot ROC
boost_tree_ROC <- roc(test_set$Target, pred_boost_prob[, "yes"])
plot(boost_tree_ROC, col = "pink")
#Calculate AUC
auc(boost_tree_ROC)


##gbm
pred_gbmcv_class<- predict(gbm_boost,test_set)
pred_gbmcv_prob<- predict(gbm_boost,test_set[,-1] ,"prob")
conf_mat_gbmcv<- table(pred_gbmcv_class,test_set$Target)
class_rate_gbmcv<-  sum(diag(conf_mat_gbmcv))/sum(conf_mat_gbmcv)
paste('Accuracy',round(class_rate_gbmcv,4))

confusionMatrix(data = pred_gbmcv_class,reference = test_set$Target)
#plot ROC
gbmcv_tree_ROC <- roc(test_set$Target,pred_gbmcv_prob[,"yes"])
plot( gbmcv_tree_ROC ,col="pink")
#Calculate AUC
auc(gbmcv_tree_ROC)



#knn

pred_knn_class<- predict(knn_fit,test_set)
pred_knn_prob<- predict(knn_fit,test_set ,"prob")
conf_mat_knn<- table(pred_knn_class,test_set$Target)
class_rate_knn<-  sum(diag(conf_mat_knn))/sum(conf_mat_knn)
paste('Accuracy',round(class_rate_knn,4))
confusionMatrix(data = pred_knn_class,reference = test_set$Target)
#0.7351
#plot ROC
knn_ROC <- roc(test_set$Target,pred_knn_prob[,"yes"])
plot(knn_ROC,col="darkgrey")
#Calculate AUC
auc(knn_ROC)


##Linear svm
pred_Ltune_class<- predict(L_tune$best.model,test_set_scale)
pred_Ltune_prob<- predict(L_tune$best.model,test_set ,probability = T)
#conf_mat_Ltune<- table(pred_Ltune_class,test_set$Target)
class_rate_Ltune<-  mean(pred_Ltune_class == test_set_scale$Target)
paste('Accuracy',round(class_rate_Ltune,4))
confusionMatrix(data = pred_Ltune_class,reference = test_set_scale$Target)
#0.694
SVMLt_prop <- attr(pred_Ltune_prob,"probabilities")
Lt_ROC <- roc(test_set_scale$Target,SVMLt_prop[1:268])
plot(Lt_ROC,col="darkgrey")
#Calculate AUC
auc(Lt_ROC)

##radial svm
pred_Rtune_class<- predict(R_tune$best.model,test_set_scale)
pred_Rtune_prob<- predict(R_tune$best.model,test_set_scale ,probability = T)
#conf_mat_Ltune<- table(pred_Ltune_class,test_set$Target)
class_rate_Rtune<-  mean(pred_Rtune_class == test_set_scale$Target)
paste('Accuracy',round(class_rate_Rtune,4))
confusionMatrix(data = pred_Rtune_class,reference = test_set_scale$Target)
#0.694
SVMRt_prop <- attr(pred_Rtune_prob,"probabilities")
Rt_ROC <- roc(test_set_scale$Target,SVMRt_prop[1:268])
plot(Rt_ROC,col="darkgrey")
#Calculate AUC
auc(Rt_ROC)


#polynomial
pred_Ptune_class<- predict(P_tune$best.model,test_set_scale)
pred_Ptune_prob<- predict(P_tune$best.model,test_set_scale ,probability = T)
#conf_mat_Ltune<- table(pred_Ltune_class,test_set$Target)
class_rate_Ptune<-  mean(pred_Ptune_class == test_set_scale$Target)
paste('Accuracy',round(class_rate_Ptune,4))
confusionMatrix(data = pred_Ptune_class,reference = test_set_scale$Target)
#0.694
SVMPt_prop <- attr(pred_Ptune_prob,"probabilities")
Pt_ROC <- roc(test_set_scale$Target,SVMPt_prop[1:268])
plot(Pt_ROC,col="darkgrey")
#Calculate AUC
auc(Pt_ROC)


#######################################################################################
plot(cv_tree_ROC,col=c(1),main="ROC for All Classification models")
plot(bag_cv_ROC,add=TRUE,col=c(2)) # color magenta is bagg
plot(rfcv_tree_ROC,add=TRUE,col=c(3)) # color black is rf
plot(boost_tree_ROC,add=TRUE,col=c(4)) # color red is cforest
plot(gbmcv_tree_ROC,add=TRUE,col=c(5)) # color green is gbm
plot(knn_ROC,add=TRUE,col=c(6)) # color red is cforest
plot(Lt_ROC,add=TRUE,col=c(7)) # color green is gbm
plot(Rt_ROC,add=TRUE,col=c(8)) # color green is gbm
plot(Pt_ROC,add=TRUE,col=c(9)) # color green is gbm
legend('topright', c("Tree","Bagging","RF","C5.0","GBM","Knn","svmL","svmR","svmP"), 
       lty=1, col=1:9, bty='n', cex=.75)

###########################################################################################################
###########################################################################################################
#############################################################################################
#Models Comparisons using the cross validation and CARET.

set.seed(234)
control <- trainControl(method="repeatedcv", number=10, repeats=3,classProbs = TRUE)
# CART
set.seed(234)
fit.tree <- train(Target~., data=train_set[,-1], method="rpart", trControl=control,metric="ROC")
set.seed(234)
fit.bag <- train(Target ~., data=train_set[,-1], method="treebag", trControl=control,metric="ROC")
set.seed(234)
fit.rf <- train(Target ~., data=train_set[,-1], method="rf", trControl=control,metric="ROC")
set.seed(234)
fit.gbm <- train(Target ~., data=train_set[,-1], method="gbm", trControl=control,metric="ROC")
set.seed(234)
fit.c50 <- train(Target~., data=train_set[,-1], method="C5.0", trControl=control,metric="ROC")
set.seed(234)
fit.svmL <- train(Target~., data=train_set[,-1], method="svmLinear", trControl=control,metric="ROC")
set.seed(234)
fit.svmR <- train(Target ~., data=train_set[,-1], method="svmRadial", trControl=control,metric="ROC")
set.seed(234)
fit.knn<- train(Target~., data=train_set[,-1], method="knn", trControl=control,metric="ROC")

results <- resamples(list(Tree=fit.tree, Bagging=fit.bag,RF=fit.rf,GBM=fit.gbm,C50=fit.c50, SVML=fit.svmL,SVMR=fit.svmR, KNN=fit.knn))

# summarize differences between modes
summary(results)

# box and whisker plots to compare models
scales <- list(x=list(relation="free"), y=list(relation="free"))
bwplot(results, scales=scales)
# density plots of accuracy
scales <- list(x=list(relation="free"), y=list(relation="free"))
densityplot(results, scales=scales, pch = "|")


# dot plots of accuracy
scales <- list(x=list(relation="free"), y=list(relation="free"))
dotplot(results, scales=scales)

# parallel plots to compare models
parallelplot(results)

# pair-wise scatterplots of predictions to compare models
splom(results)

# xyplot plots to compare models
xyplot(results, models=c("GBM", "SVMR"))

diffs <- diff(results)
# summarize p-values for pair-wise comparisons
summary(diffs)


